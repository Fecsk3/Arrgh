from freeGPT import AsyncClient, Client

__author__ = "Ruu3f"
__version__ = "1.3.4"
