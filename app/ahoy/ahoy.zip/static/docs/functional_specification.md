# Functional Specification
## 1. Description of the Current Situation

## 2. Description of the Desired System

## 3. Model of Current Business Processes

## 4. Model of Required Business Processes

## 5. Requirements List

| Id | Module | Name | Description |
| :---: | --- | --- | --- |
| K1 | ...| ... | ... |

## 6. Use Cases

## 7. Mapping: How Use Cases Align with Requirements

## 8. Screen Designs

![image name](git link where the image is)

## 9. Scenarios

## 10. Mapping of Functions to Requirements

| Id | Requirement | Function |
| :---: | --- | --- |
| K4 | ... | ... |

## 11. Glossary
