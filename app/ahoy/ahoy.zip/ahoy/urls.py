"""
URL configuration for ahoy project.

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/5.0/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  path('', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  path('', Home.as_view(), name='home')
Including another URLconf
    1. Import the include() function: from django.urls import include, path
    2. Add a URL to urlpatterns:  path('blog/', include('blog.urls'))
"""
from django.contrib import admin
from django.urls import include, path, re_path
from django.views.generic import RedirectView
from django.views.static import serve
from django.conf import settings
from documents.views import documents_markdown_files_list, download_markdown_file
from django.conf.urls import handler404
from django.shortcuts import render


def custom_404(request, exception):
    return render(request, '404.html', {}, status=404)

handler404 = custom_404


urlpatterns = [
    path('documents/', documents_markdown_files_list, name='documents'),
    path('download-markdown-file/<int:file_id>/', download_markdown_file, name='download_markdown_file'),
    re_path(r'static/(?P<path>.*)', serve, {'document_root': settings.STATIC_ROOT}),
    path('', include('index.urls')),
    path('', include('register.urls')),
    path('', include('login.urls')),
    path('', include('kanban.urls')),
    path('', include('gpt.urls')),
    path('', include('profil.urls')),
    path('', include('team.urls')),
    path('', RedirectView.as_view(url='/login/')),
    path('admin/', admin.site.urls),
    path('', include('messages.urls')),
]